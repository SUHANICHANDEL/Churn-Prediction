from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from werkzeug.utils import secure_filename
from ml_model import predict_from_csv
import requests

# 🛠️ App Config
app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = "uploads"
ALLOWED_EXTENSIONS = {"csv"}
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# 🔍 Check file extension
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# 📤 Upload CSV
@app.route("/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No selected file"}), 400

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(save_path)
        return jsonify({"message": "File uploaded successfully", "filename": filename}), 200

    return jsonify({"error": "Invalid file type"}), 400

# 🤖 Churn Prediction
@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()
    filename = data.get("filename")

    if not filename:
        return jsonify({"error": "Filename is missing"}), 400

    file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)

    try:
        df_with_predictions = predict_from_csv(file_path)
        result = df_with_predictions.to_dict(orient="records")
        print("✅ Prediction counts:")
        print(df_with_predictions["churn_prediction"].value_counts())
        return jsonify({"message": "Prediction successful", "results": result}), 200

    except Exception as e:
        import traceback
        print("\n❌ Prediction Error Traceback:")
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

# 🧠 LLM Summary via Ollama
@app.route("/llm_summary", methods=["POST"])
def llm_summary():
    print("📥 Received POST request at /llm_summary")
    try:
        data = request.get_json()
        print("📊 Payload received:", data)

        total_users = data.get("totalUsers", 0)
        churned_users = data.get("churnedUsers", 0)
        high_risk_users = data.get("highRiskUsers", 0)
        avg_tenure = round(data.get("avgTenure", 0), 1)
        avg_inactive_days = round(data.get("avgInactiveDays", 0), 1)

        prompt = (
            f"You are a business analyst. Based on the data:\n"
            f"- Total Users: {total_users}\n"
            f"- Churned Users: {churned_users}\n"
            f"- High Risk Users: {high_risk_users}\n"
            f"- Avg Tenure (months): {avg_tenure}\n"
            f"- Avg Inactive Days: {avg_inactive_days}\n"
            f"Generate a brief and meaningful summary highlighting customer churn trends, risk factors, and suggested next steps."
        )

        print("🧠 Sending prompt to Ollama...")

        # 🔥 ADDED: log full Ollama request + response status
        ollama_response = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": "mistral", "prompt": prompt, "stream": False}
        )

        print(f"📶 Ollama status: {ollama_response.status_code}")
        print("📥 Ollama raw response:", ollama_response.text)

        result = ollama_response.json()

        print("✅ LLM Summary response:", result["response"])
        return jsonify({"summary": result["response"]}), 200

    except Exception as e:
        import traceback
        print("❌ LLM Summary Error:")
        traceback.print_exc()
        return jsonify({"error": "LLM summarization failed"}), 500


# 🚀 Run Server
if __name__ == "__main__":
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    app.run(debug=True)
