# backend/save_model.py

import pandas as pd
import xgboost as xgb
import joblib
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# 📄 Path to training data
csv_path = "training_data.csv"

# ✅ Load data
df = pd.read_csv(csv_path)

# 🧹 Drop unnecessary ID columns
if 'user_id' in df.columns:
    df = df.drop(columns=['user_id'])

# 🎯 Set correct target column
target_col = "churned"  # ✅ Use consistent label
if target_col not in df.columns:
    raise ValueError(f"Target column '{target_col}' not found in the dataset.")

X = df.drop(columns=[target_col])
y = df[target_col]

# 📊 Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ⚙️ Train model with class imbalance handling
scale_pos_weight = (y_train == 0).sum() / max((y_train == 1).sum(), 1)
model = xgb.XGBClassifier(use_label_encoder=False, eval_metric='logloss', scale_pos_weight=scale_pos_weight)
model.fit(X_train, y_train)

# 💾 Save model
model_filename = "xgboost_model.pkl"
joblib.dump(model, model_filename)
print(f"✅ Model trained and saved as: {model_filename}")

# 📈 Evaluate
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"✅ Accuracy: {accuracy:.4f}")
print(f"✅ Churn predictions in test set: {sum(y_pred)} out of {len(y_pred)}")
