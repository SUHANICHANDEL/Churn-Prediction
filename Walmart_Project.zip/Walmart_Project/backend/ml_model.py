# backend/ml_model.py

import pandas as pd
import joblib
import os

model_path = "xgboost_model.pkl"

if not os.path.exists(model_path):
    print(f"⚠️ Model file not found at: {model_path}. Prediction won't work until model is trained.")
    model = None
else:
    model = joblib.load(model_path)

def predict_from_csv(file_path):
    df = pd.read_csv(file_path)

    # ❗ Drop 'churned' if present — it's the label, not a feature
    if "churned" in df.columns:
        df = df.drop(columns=["churned"])

    if model is None:
        raise ValueError("❌ Model is not loaded")

    # 🔍 Predict churn (1 = churned, 0 = not churned)
    predictions = model.predict(df)
    df["churn_prediction"] = predictions

    # ✅ Logging for debug
    print("✅ Prediction counts:")
    print(df["churn_prediction"].value_counts())

    return df
