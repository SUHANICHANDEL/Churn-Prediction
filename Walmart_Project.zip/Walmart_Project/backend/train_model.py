# backend/train_model.py

import pandas as pd
import xgboost as xgb
import joblib
import os

# 📁 Load sample training data
df = pd.read_csv("uploads/sample_walmart_users.csv")

# 🧹 Drop unnecessary column
if 'user_id' in df.columns:
    df = df.drop(columns=['user_id'])

# 🎯 Features and target (ensure target column is 'churned')
X = df.drop(columns=["churned"])
y = df["churned"]

# ⚙️ Train model with class balance handling
model = xgb.XGBClassifier(use_label_encoder=False, eval_metric='logloss', scale_pos_weight=(y == 0).sum() / (y == 1).sum())
model.fit(X, y)

# 💾 Save model
joblib.dump(model, "xgboost_model.pkl")
print("✅ Model trained and saved as xgboost_model.pkl")
