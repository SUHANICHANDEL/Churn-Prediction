import React from 'react';
import { useNavigate } from 'react-router-dom';
import './LandingPage.css';

function LandingPage() {
  const navigate = useNavigate();

  const handleStart = () => {
    navigate('/upload');
  };

  return (
    <div className="landing">
      <div className="content">
        <h1 className="title">Walmart+ Churn Prediction</h1>
        <p className="subtitle">Predict and prevent subscription churn with smart alerts and offers.</p>
        <button className="start-button" onClick={handleStart}>
          🚀 Start
        </button>
      </div>
    </div>
  );
}

export default LandingPage;
