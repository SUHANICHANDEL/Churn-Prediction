// frontend/src/pages/CustomersPage.jsx

import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Dashboard.css";

const CustomersPage = () => {
  const navigate = useNavigate();
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    const results = JSON.parse(localStorage.getItem("predictionResults")) || [];
    setCustomers(results);
  }, []);

  return (
    <div className="page-container">
      <h1>👥 Customer Predictions</h1>

      <table>
        <thead>
          <tr>
            <th>Customer ID</th>
            <th>Tenure (Months)</th>
            <th>Days Since Last Login</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((user, index) => (
            <tr key={index}>
              <td>{user.customer_id || "N/A"}</td>
              <td>{user.tenure_months}</td>
              <td>{user.days_since_last_login}</td>
              <td>
  {user.churn_prediction === 1 ? (
    <span style={{ color: "red", fontWeight: "bold" }}>⚠️ At Risk</span>
  ) : (
    <span style={{ color: "green", fontWeight: "bold" }}>✅ Active</span>
  )}
</td>

            </tr>
          ))}
        </tbody>
      </table>

      <button onClick={() => navigate("/dashboard")}>← Back to Dashboard</button>
    </div>
  );
};

export default CustomersPage;
