// frontend/src/pages/AlertsPage.jsx

import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Dashboard.css";

const AlertsPage = () => {
  const navigate = useNavigate();
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    const results = JSON.parse(localStorage.getItem("predictionResults")) || [];

    const generatedAlerts = [];

    results.forEach((user) => {
      const userId = user.customer_id || "N/A";

      if (user.prediction === 1) {
        generatedAlerts.push(`⚠️ User ${userId} predicted to churn`);
      }
      if (user.tenure_months < 3) {
        generatedAlerts.push(`📉 User ${userId} has low tenure (${user.tenure_months} months)`);
      }
      if (user.days_since_last_login > 20) {
        generatedAlerts.push(`⏱️ User ${userId} inactive for ${user.days_since_last_login} days`);
      }
    });

    setAlerts(generatedAlerts);
  }, []);

  return (
    <div className="page-container">
      <h1>🚨 Churn Alerts</h1>
      {alerts.length === 0 ? (
        <p>No alerts to show. 🎉</p>
      ) : (
        <ul>
          {alerts.map((alert, index) => (
            <li key={index}>{alert}</li>
          ))}
        </ul>
      )}
      <button onClick={() => navigate("/dashboard")}>← Back to Dashboard</button>
    </div>
  );
};

export default AlertsPage;
