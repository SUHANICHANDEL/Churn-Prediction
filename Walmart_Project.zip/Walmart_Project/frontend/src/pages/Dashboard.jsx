import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Dashboard.css";

const Dashboard = () => {
  const navigate = useNavigate();
  const [totalUsers, setTotalUsers] = useState(0);
  const [churnedUsers, setChurnedUsers] = useState(0);
  const [churnRate, setChurnRate] = useState("0%");
  const [highRiskUsers, setHighRiskUsers] = useState(0);
  const [llmSummary, setLLMSummary] = useState("");

  useEffect(() => {
    const results = JSON.parse(localStorage.getItem("predictionResults")) || [];

    console.log("📦 Loaded predictionResults from localStorage:", results);

    setTotalUsers(results.length);

    const churned = results.filter((user) => user.churn_prediction === 1);
    console.log("🔍 Churned users:", churned);

    setChurnedUsers(churned.length);

    const rate =
      results.length > 0
        ? ((churned.length / results.length) * 100).toFixed(1) + "%"
        : "0%";
    setChurnRate(rate);
    console.log("📊 Churn rate:", rate);

    const risky = results.filter(
      (user) => user.days_since_last_login > 20 || user.tenure_months < 3
    );
    console.log("⚠️ High risk users:", risky);

    setHighRiskUsers(risky.length);

    const generateLLMSummary = async () => {
      const payload = {
        totalUsers: results.length,
        churnedUsers: churned.length,
        highRiskUsers: risky.length,
        avgTenure:
          risky.reduce((sum, u) => sum + u.tenure_months, 0) / (risky.length || 1),
        avgInactiveDays:
          risky.reduce((sum, u) => sum + u.days_since_last_login, 0) / (risky.length || 1),
      };

      console.log("📤 Sending payload to /llm_summary:", payload);

      try {
        const response = await fetch("http://localhost:5000/llm_summary", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });

        console.log("📥 Raw response object:", response);

        const text = await response.text(); // raw body
        console.log("🧾 Raw response body:", text);

        let data;
        try {
          data = JSON.parse(text);
        } catch (jsonErr) {
          console.error("❌ Failed to parse JSON:", jsonErr);
          return;
        }

        console.log("✅ Parsed response JSON:", data);
if (data.response) {
  console.log("🧠 Setting LLM summary in state...");
  setLLMSummary(data.response);
} else if (data.summary) {
  // fallback in case backend is modified later
  console.log("🧠 Setting fallback summary...");
  setLLMSummary(data.summary);
} else {
  console.warn("⚠️ No summary or response key in LLM API result.");
}

      } catch (err) {
        console.error("❌ LLM summary fetch failed:", err);
      }
    };

    generateLLMSummary();
  }, []);

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">📊 Walmart+ Churn Dashboard</header>

      <section className="dashboard-section">
        <h2>🔢 Overview</h2>
        <div className="stats-grid">
          <div className="stat-box">
            <h3>Total Users</h3>
            <p>{totalUsers}</p>
          </div>
          <div className="stat-box">
            <h3>Churn Rate</h3>
            <p>{churnRate}</p>
          </div>
          <div className="stat-box">
            <h3>High Risk Users</h3>
            <p>{highRiskUsers}</p>
          </div>
        </div>

        <div className="action-buttons">
          <button onClick={() => navigate("/alerts")}>🚨 View Alerts</button>
          <button onClick={() => navigate("/customers")}>👤 View Customers</button>
        </div>
      </section>

      <section className="dashboard-section">
        <h2>🧠 Smart Insights</h2>
        <div className="llm-summary-box">
          {llmSummary ? (
            llmSummary.split("\n").map((line, index) => (
              <p key={index}>{line}</p>
            ))
          ) : (
            <p>Generating insights from LLM...</p>
          )}
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
