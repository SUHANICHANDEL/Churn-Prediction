import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./UploadPage.css";

const UploadPage = () => {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    setMessage("");
  };

  const handleUpload = async () => {
    if (!file) {
      setMessage("⚠️ Please select a CSV file to upload.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await axios.post("http://127.0.0.1:5000/upload", formData);
      setMessage("✅ " + res.data.message);

      const filename = res.data.filename;

      // ⏳ Now send to /predict
      const predictRes = await axios.post("http://127.0.0.1:5000/predict", {
        filename: filename,
      });

      // 💾 Save result to localStorage to access on dashboard
      localStorage.setItem("predictionResults", JSON.stringify(predictRes.data.results));

      // ✅ Navigate to dashboard
      setTimeout(() => navigate("/dashboard"), 1000);
    } catch (error) {
      console.error(error);
      setMessage("❌ Upload failed. Please try again.");
    }
  };

  return (
    <div className="upload-container">
      <div className="upload-card">
        <h1>📤 Upload Your CSV</h1>
        <p>Make sure your file contains valid user data for churn prediction.</p>

        <input
          type="file"
          accept=".csv"
          onChange={handleFileChange}
          className="file-input"
        />

        <button onClick={handleUpload}>Upload File</button>

        {message && <div className="message">{message}</div>}
      </div>
    </div>
  );
};

export default UploadPage;
